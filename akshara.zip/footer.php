<?php include "link.php"?>
        <div class="container-fluid footer-container">
            <div class="row">
                <div class="col-md-2">
                    <a class="footer-link" href="#index.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Home</a><br/>
                    <a class="footer-link" href="index.php#aboutus"><i class="fa fa-sign-out" aria-hidden="true"></i> About Us</a><br/>
                    <a class="footer-link" href="courses.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Courses</a><br/>
                    <a class="footer-link" href="index.php#features"><i class="fa fa-sign-out" aria-hidden="true"></i> Features</a><br/>
                    <a class="footer-link" href="index.php#gallery"><i class="fa fa-sign-out" aria-hidden="true"></i> Gallery</a><br/>
                    <a class="footer-link" href="index.php#contact"><i class="fa fa-sign-out" aria-hidden="true"></i> Contact Us</a><br class="mobile"/>
                </div>
                <div class="col-md-4">
                    <br class="mobile"/>
                    <i style="color:white" class="fa fa-3x fa-map-marker" aria-hidden="true"></i>
                    <p class="footer-text">Ist Floor Kalashree Building,opp-IOC,Khanapur Road,Belgaum-590006</p>

                    <a href="https://www.facebook.com/Akshara-coaching-Belagavi-109184897374736/"><i style="color:white;margin:10px" class="fa fa-3x fa-facebook-official" aria-hidden="true"></i></a>
                    <i style="color:white;margin:10px" class="fa fa-3x fa-instagram" aria-hidden="true"></i>
                </div>
                <div class="col-md-3">
                    <br class="mobile"/>
                    <i style="color:white;" class="fa fa-3x fa-phone" aria-hidden="true"></i>
                    <p class="footer-text">0831-4203339 / 9611303339</p><br/>
                    <i style="color:white" class="fa fa-3x fa-envelope-o" aria-hidden="true"></i>
                    <h5 class="footer-text">aksharabgm@gmail.com</h5><br/>
                </div>
                <div class="col-md-3 footer-logo">
                    <img src="images/logo.png" class="img-fluid">
                </div>
            </div>
        </div>
        <div class="container-fluid copyright-container">
            <h6 class="" style="text-align:center">©2020 Akshara | Designed by <a style="color:white;text-decoration:none" href="http://evonitsolutions.com/">Evon IT Solutions</a>.All rights are Reserved</h6>
        </div>

        <script src="js/wow.min.js"></script>
                        <script>
                        new WOW().init();
                        </script>
    </body>
</html>